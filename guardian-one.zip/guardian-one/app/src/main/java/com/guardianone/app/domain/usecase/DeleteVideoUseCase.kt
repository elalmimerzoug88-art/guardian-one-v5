package com.guardianone.app.domain.usecase

import com.guardianone.app.domain.model.VideoModel
import com.guardianone.app.domain.repository.GuardianRepository
import java.io.File
import javax.inject.Inject

class DeleteVideoUseCase @Inject constructor(
    private val repository: GuardianRepository
) {
    suspend operator fun invoke(video: VideoModel) {
        // Remove from DB
        repository.deleteVideo(video)
        // Try deleting physical file
        try {
            val file = File(video.filePath)
            if (file.exists()) {
                file.delete()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
