package com.guardianone.app.ui.camera

import android.content.Context
import androidx.camera.core.CameraSelector
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.guardianone.app.camera.CameraManager
import com.guardianone.app.camera.MotionAnalyzer
import com.guardianone.app.camera.MotionState
import com.guardianone.app.camera.VideoRecorder
import com.guardianone.app.data.repository.MotionSettingsRepository
import com.guardianone.app.domain.model.VideoModel
import com.guardianone.app.domain.usecase.AddEventUseCase
import com.guardianone.app.domain.usecase.AddVideoUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import kotlin.math.max

@HiltViewModel
class CameraViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    val cameraManager: CameraManager,
    private val addEventUseCase: AddEventUseCase,
    private val addVideoUseCase: AddVideoUseCase,
    private val motionSettingsRepository: MotionSettingsRepository
) : ViewModel() {

    private val _lensFacing = MutableStateFlow(CameraSelector.LENS_FACING_BACK)
    val lensFacing: StateFlow<Int> = _lensFacing.asStateFlow()

    private val _motionPercentage = MutableStateFlow(0f)
    val motionPercentage: StateFlow<Float> = _motionPercentage.asStateFlow()

    private val _motionState = MutableStateFlow(MotionState.NO_MOTION)
    val motionState: StateFlow<MotionState> = _motionState.asStateFlow()

    private val _cameraError = MutableStateFlow<String?>(null)
    val cameraError: StateFlow<String?> = _cameraError.asStateFlow()

    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()

    private val _isAutoRecording = MutableStateFlow(false)
    val isAutoRecording: StateFlow<Boolean> = _isAutoRecording.asStateFlow()

    private val _autoStopCountdownSeconds = MutableStateFlow<Int?>(null)
    val autoStopCountdownSeconds: StateFlow<Int?> = _autoStopCountdownSeconds.asStateFlow()

    private val _notificationMessage = MutableStateFlow<String?>(null)
    val notificationMessage: StateFlow<String?> = _notificationMessage.asStateFlow()

    val motionSettings = motionSettingsRepository.settings

    private val videoRecorder = VideoRecorder()
    private var autoStopJob: Job? = null
    private var lastLoggedTime = 0L
    private var currentPeakMotion = 0f

    val motionAnalyzer = MotionAnalyzer(viewModelScope) { percentage, state ->
        _motionPercentage.value = percentage
        _motionState.value = state

        val settings = motionSettingsRepository.settings.value
        val threshold = settings.activeThreshold
        val autoStopDelay = settings.autoStopDelaySeconds
        val currentTime = System.currentTimeMillis()

        if (percentage >= threshold) {
            currentPeakMotion = max(currentPeakMotion, percentage)

            // Cancel any pending auto-stop delay timer
            autoStopJob?.cancel()
            autoStopJob = null
            _autoStopCountdownSeconds.value = null

            // Event log rate limit
            if (currentTime - lastLoggedTime > 3000) {
                lastLoggedTime = currentTime
                viewModelScope.launch {
                    addEventUseCase(
                        title = "Motion Detected",
                        description = "Motion ${percentage.toInt()}% reached threshold (${threshold.toInt()}%). State: ${state.label}",
                        status = "WARNING"
                    )
                }
            }

            // Auto-start video recording if not active
            if (!videoRecorder.isRecording) {
                val vCapture = cameraManager.videoCapture
                if (vCapture != null) {
                    _isAutoRecording.value = true
                    showNotification("تم اكتشاف حركة - بدأ التسجيل")

                    viewModelScope.launch {
                        addEventUseCase(
                            title = "Auto Recording Started",
                            description = "Motion level ${percentage.toInt()}% triggered automatic video recording.",
                            status = "WARNING"
                        )
                    }

                    videoRecorder.startRecording(
                        context = context,
                        videoCapture = vCapture,
                        initialPeakMotion = percentage,
                        onStarted = {
                            _isRecording.value = true
                        },
                        onFinished = { filePath, fileName, duration, sizeBytes ->
                            _isRecording.value = false
                            _isAutoRecording.value = false
                            _autoStopCountdownSeconds.value = null

                            showNotification("تم حفظ الفيديو بنجاح")

                            viewModelScope.launch {
                                addVideoUseCase(
                                    VideoModel(
                                        fileName = fileName,
                                        filePath = filePath,
                                        fileSizeBytes = sizeBytes,
                                        durationSeconds = duration,
                                        startTimeMs = videoRecorder.currentRecordingStartTimeMs,
                                        endTimeMs = System.currentTimeMillis(),
                                        peakMotionPercentage = currentPeakMotion,
                                        isAutoRecorded = true
                                    )
                                )
                                addEventUseCase(
                                    title = "Video Saved",
                                    description = "Saved $fileName ($duration s) to Movies/GuardianOne.",
                                    status = "SUCCESS"
                                )
                                currentPeakMotion = 0f
                            }
                        },
                        onError = { err ->
                            _isRecording.value = false
                            _isAutoRecording.value = false
                            _autoStopCountdownSeconds.value = null
                            _cameraError.value = err
                        }
                    )
                }
            }
        } else {
            // Motion fell below threshold
            if (_isRecording.value && _isAutoRecording.value && autoStopJob == null) {
                autoStopJob = viewModelScope.launch {
                    for (i in autoStopDelay downTo 1) {
                        _autoStopCountdownSeconds.value = i
                        delay(1000L)
                    }
                    _autoStopCountdownSeconds.value = 0
                    videoRecorder.stopRecording()
                }
            }
        }
    }

    fun toggleManualRecording() {
        // Disable manual trigger if auto recording is active
        if (_isAutoRecording.value) {
            showNotification("التسجيل التلقائي يعمل حالياً")
            return
        }

        if (videoRecorder.isRecording) {
            // Stop manual recording
            autoStopJob?.cancel()
            autoStopJob = null
            videoRecorder.stopRecording()
        } else {
            // Start manual recording
            val vCapture = cameraManager.videoCapture ?: return
            _isAutoRecording.value = false
            currentPeakMotion = _motionPercentage.value
            showNotification("بدأ التسجيل اليدوي")

            viewModelScope.launch {
                addEventUseCase(
                    title = "Manual Recording Started",
                    description = "Manual video recording initiated by user.",
                    status = "INFO"
                )
            }

            videoRecorder.startRecording(
                context = context,
                videoCapture = vCapture,
                initialPeakMotion = currentPeakMotion,
                onStarted = {
                    _isRecording.value = true
                },
                onFinished = { filePath, fileName, duration, sizeBytes ->
                    _isRecording.value = false
                    _isAutoRecording.value = false
                    _autoStopCountdownSeconds.value = null

                    showNotification("تم حفظ الفيديو بنجاح")

                    viewModelScope.launch {
                        addVideoUseCase(
                            VideoModel(
                                fileName = fileName,
                                filePath = filePath,
                                fileSizeBytes = sizeBytes,
                                durationSeconds = duration,
                                startTimeMs = videoRecorder.currentRecordingStartTimeMs,
                                endTimeMs = System.currentTimeMillis(),
                                peakMotionPercentage = currentPeakMotion,
                                isAutoRecorded = false
                            )
                        )
                        addEventUseCase(
                            title = "Video Saved",
                            description = "Saved manual $fileName ($duration s) to Movies/GuardianOne.",
                            status = "SUCCESS"
                        )
                        currentPeakMotion = 0f
                    }
                },
                onError = { err ->
                    _isRecording.value = false
                    _isAutoRecording.value = false
                    _autoStopCountdownSeconds.value = null
                    _cameraError.value = err
                }
            )
        }
    }

    fun toggleCameraLens() {
        val nextLens = if (_lensFacing.value == CameraSelector.LENS_FACING_BACK) {
            CameraSelector.LENS_FACING_FRONT
        } else {
            CameraSelector.LENS_FACING_BACK
        }
        _lensFacing.value = nextLens

        viewModelScope.launch {
            val lensName = if (nextLens == CameraSelector.LENS_FACING_BACK) "BACK" else "FRONT"
            addEventUseCase(
                title = "Camera Switch",
                description = "Switched to $lensName camera lens",
                status = "INFO"
            )
        }
    }

    private fun showNotification(message: String) {
        _notificationMessage.value = message
        viewModelScope.launch {
            delay(4000L)
            if (_notificationMessage.value == message) {
                _notificationMessage.value = null
            }
        }
    }

    fun dismissNotification() {
        _notificationMessage.value = null
    }

    fun onCameraError(exception: Exception) {
        _cameraError.value = exception.localizedMessage ?: "Unknown Camera Error"
        viewModelScope.launch {
            addEventUseCase(
                title = "Camera Error",
                description = _cameraError.value ?: "Error initializing camera",
                status = "ERROR"
            )
        }
    }

    fun onCameraStarted() {
        viewModelScope.launch {
            addEventUseCase(
                title = "Camera Active",
                description = "Live Motion Analysis & Smart Recording Engine Initialized",
                status = "ACTIVE"
            )
        }
    }
}
