package com.guardianone.app.domain.usecase

import com.guardianone.app.domain.model.EventModel
import com.guardianone.app.domain.repository.GuardianRepository
import javax.inject.Inject

class AddEventUseCase @Inject constructor(
    private val repository: GuardianRepository
) {
    suspend operator fun invoke(title: String, description: String, status: String = "INFO") {
        val event = EventModel(
            title = title,
            description = description,
            status = status
        )
        repository.insertEvent(event)
    }
}
