package com.guardianone.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.guardianone.app.data.local.dao.EventDao
import com.guardianone.app.data.local.dao.VideoDao
import com.guardianone.app.data.local.entity.EventEntity
import com.guardianone.app.data.local.entity.VideoEntity

@Database(entities = [EventEntity::class, VideoEntity::class], version = 2, exportSchema = false)
abstract class GuardianDatabase : RoomDatabase() {
    abstract fun eventDao(): EventDao
    abstract fun videoDao(): VideoDao
}
