package com.guardianone.app.domain.usecase

import com.guardianone.app.domain.model.VideoModel
import com.guardianone.app.domain.repository.GuardianRepository
import javax.inject.Inject

class AddVideoUseCase @Inject constructor(
    private val repository: GuardianRepository
) {
    suspend operator fun invoke(video: VideoModel): Long {
        return repository.insertVideo(video)
    }
}
