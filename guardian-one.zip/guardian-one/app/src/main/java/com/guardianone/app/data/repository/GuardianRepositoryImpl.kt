package com.guardianone.app.data.repository

import com.guardianone.app.data.local.dao.EventDao
import com.guardianone.app.data.local.dao.VideoDao
import com.guardianone.app.data.local.entity.toDomain
import com.guardianone.app.data.local.entity.toEntity
import com.guardianone.app.domain.model.EventModel
import com.guardianone.app.domain.model.VideoModel
import com.guardianone.app.domain.repository.GuardianRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

class GuardianRepositoryImpl @Inject constructor(
    private val eventDao: EventDao,
    private val videoDao: VideoDao
) : GuardianRepository {

    override fun getAllEvents(): Flow<List<EventModel>> {
        return eventDao.getAllEvents().map { entities ->
            entities.map { it.toDomain() }
        }
    }

    override suspend fun insertEvent(event: EventModel) {
        eventDao.insertEvent(event.toEntity())
    }

    override suspend fun deleteEvent(event: EventModel) {
        eventDao.deleteEvent(event.toEntity())
    }

    override fun getAllVideos(): Flow<List<VideoModel>> {
        return videoDao.getAllVideos().map { entities ->
            entities.map { it.toDomain() }
        }
    }

    override suspend fun insertVideo(video: VideoModel): Long {
        return videoDao.insertVideo(video.toEntity())
    }

    override suspend fun deleteVideo(video: VideoModel) {
        videoDao.deleteVideo(video.toEntity())
    }

    override suspend fun deleteVideoById(id: Long) {
        videoDao.deleteVideoById(id)
    }
}
