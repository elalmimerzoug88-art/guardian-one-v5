# ProGuard rules for Guardian One
-keep class com.guardianone.app.** { *; }
