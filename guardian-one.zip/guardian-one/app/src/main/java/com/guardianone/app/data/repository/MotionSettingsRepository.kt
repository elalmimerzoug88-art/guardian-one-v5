package com.guardianone.app.data.repository

import android.content.Context
import com.guardianone.app.domain.model.MotionSettings
import com.guardianone.app.domain.model.SensitivityPreset
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MotionSettingsRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val prefs = context.getSharedPreferences("guardian_settings", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(
        MotionSettings(
            preset = SensitivityPreset.valueOf(
                prefs.getString("preset", SensitivityPreset.MEDIUM.name) ?: SensitivityPreset.MEDIUM.name
            ),
            customThreshold = prefs.getFloat("customThreshold", 15f),
            autoStopDelaySeconds = prefs.getInt("autoStopDelaySeconds", 10),
            autoStartOnBoot = prefs.getBoolean("autoStartOnBoot", false),
            startServiceOnAppOpen = prefs.getBoolean("startServiceOnAppOpen", false),
            stopOnLowBattery = prefs.getBoolean("stopOnLowBattery", true)
        )
    )
    val settings: StateFlow<MotionSettings> = _settings.asStateFlow()

    fun updatePreset(preset: SensitivityPreset) {
        _settings.value = _settings.value.copy(preset = preset)
        prefs.edit().putString("preset", preset.name).apply()
    }

    fun updateCustomThreshold(threshold: Float) {
        _settings.value = _settings.value.copy(
            preset = SensitivityPreset.CUSTOM,
            customThreshold = threshold
        )
        prefs.edit()
            .putString("preset", SensitivityPreset.CUSTOM.name)
            .putFloat("customThreshold", threshold)
            .apply()
    }

    fun updateAutoStopDelay(seconds: Int) {
        val clamped = seconds.coerceIn(5, 120)
        _settings.value = _settings.value.copy(autoStopDelaySeconds = clamped)
        prefs.edit().putInt("autoStopDelaySeconds", clamped).apply()
    }

    fun updateAutoStartOnBoot(enabled: Boolean) {
        _settings.value = _settings.value.copy(autoStartOnBoot = enabled)
        prefs.edit().putBoolean("autoStartOnBoot", enabled).apply()
    }

    fun updateStartServiceOnAppOpen(enabled: Boolean) {
        _settings.value = _settings.value.copy(startServiceOnAppOpen = enabled)
        prefs.edit().putBoolean("startServiceOnAppOpen", enabled).apply()
    }

    fun updateStopOnLowBattery(enabled: Boolean) {
        _settings.value = _settings.value.copy(stopOnLowBattery = enabled)
        prefs.edit().putBoolean("stopOnLowBattery", enabled).apply()
    }
}
