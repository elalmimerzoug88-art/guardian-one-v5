package com.guardianone.app.ui.theme

import androidx.compose.ui.graphics.Color

// Elegant Dark Palette
val Zinc950 = Color(0xFF09090B)
val Zinc900 = Color(0xFF18181B)
val Zinc800 = Color(0xFF27272A)
val Zinc700 = Color(0xFF3F3F46)
val Zinc400 = Color(0xFFA1A1AA)
val Zinc200 = Color(0xFFE4E4E7)

val AccentBlue = Color(0xFF3B82F6)
val AccentGreen = Color(0xFF22C55E)
val AccentAmber = Color(0xFFF59E0B)

