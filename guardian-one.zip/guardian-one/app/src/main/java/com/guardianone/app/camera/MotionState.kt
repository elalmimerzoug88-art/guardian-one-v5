package com.guardianone.app.camera

enum class MotionState(val label: String) {
    NO_MOTION("No Motion"),
    LOW_MOTION("Low Motion"),
    MEDIUM_MOTION("Medium Motion"),
    HIGH_MOTION("High Motion")
}
