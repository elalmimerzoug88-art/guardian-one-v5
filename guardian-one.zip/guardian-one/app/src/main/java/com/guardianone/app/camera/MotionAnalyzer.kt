package com.guardianone.app.camera

import android.graphics.ImageFormat
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.abs

class MotionAnalyzer(
    private val scope: CoroutineScope,
    private val onMotionCalculated: (Float, MotionState) -> Unit
) : ImageAnalysis.Analyzer {

    private var previousYBuffer: ByteArray? = null

    override fun analyze(image: ImageProxy) {
        if (image.format != ImageFormat.YUV_420_888) {
            image.close()
            return
        }

        val yPlane = image.planes[0]
        val buffer = yPlane.buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)

        scope.launch(Dispatchers.Default) {
            try {
                val prev = previousYBuffer
                if (prev != null && prev.size == bytes.size) {
                    var diffCount = 0L
                    val step = 16 // Subsample every 16th byte for high performance & low memory
                    val totalSampled = bytes.size / step

                    if (totalSampled > 0) {
                        for (i in 0 until bytes.size step step) {
                            val currentPixel = bytes[i].toInt() and 0xFF
                            val prevPixel = prev[i].toInt() and 0xFF
                            val diff = abs(currentPixel - prevPixel)
                            if (diff > 25) { // Sensitivity per pixel threshold
                                diffCount++
                            }
                        }

                        val motionPercentage = (diffCount.toFloat() / totalSampled.toFloat()) * 100f
                        val clampedPercentage = motionPercentage.coerceIn(0f, 100f)

                        val state = when {
                            clampedPercentage >= 50f -> MotionState.HIGH_MOTION
                            clampedPercentage >= 20f -> MotionState.MEDIUM_MOTION
                            clampedPercentage >= 5f -> MotionState.LOW_MOTION
                            else -> MotionState.NO_MOTION
                        }

                        onMotionCalculated(clampedPercentage, state)
                    }
                }
                previousYBuffer = bytes.clone()
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                image.close()
            }
        }
    }
}
