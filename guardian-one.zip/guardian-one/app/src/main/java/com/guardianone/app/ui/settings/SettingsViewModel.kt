package com.guardianone.app.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.guardianone.app.data.repository.MotionSettingsRepository
import com.guardianone.app.domain.model.SensitivityPreset
import com.guardianone.app.domain.usecase.AddEventUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val motionSettingsRepository: MotionSettingsRepository,
    private val addEventUseCase: AddEventUseCase
) : ViewModel() {

    val motionSettings = motionSettingsRepository.settings.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = motionSettingsRepository.settings.value
    )

    fun selectPreset(preset: SensitivityPreset) {
        motionSettingsRepository.updatePreset(preset)
        viewModelScope.launch {
            addEventUseCase(
                title = "Sensitivity Preset Changed",
                description = "Updated motion detection sensitivity to ${preset.label}",
                status = "CONFIG"
            )
        }
    }

    fun updateCustomThreshold(threshold: Float) {
        motionSettingsRepository.updateCustomThreshold(threshold)
    }

    fun updateAutoStopDelay(seconds: Int) {
        motionSettingsRepository.updateAutoStopDelay(seconds)
    }

    fun updateAutoStartOnBoot(enabled: Boolean) {
        motionSettingsRepository.updateAutoStartOnBoot(enabled)
    }

    fun updateStartServiceOnAppOpen(enabled: Boolean) {
        motionSettingsRepository.updateStartServiceOnAppOpen(enabled)
    }

    fun updateStopOnLowBattery(enabled: Boolean) {
        motionSettingsRepository.updateStopOnLowBattery(enabled)
    }
}
