package com.guardianone.app.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.guardianone.app.domain.model.EventModel
import com.guardianone.app.domain.usecase.AddEventUseCase
import com.guardianone.app.domain.usecase.GetEventsUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    getEventsUseCase: GetEventsUseCase,
    private val addEventUseCase: AddEventUseCase
) : ViewModel() {

    val recentEvents: StateFlow<List<EventModel>> = getEventsUseCase()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun logTestEvent(title: String, description: String) {
        viewModelScope.launch {
            addEventUseCase(title, description, "STATUS")
        }
    }
}
