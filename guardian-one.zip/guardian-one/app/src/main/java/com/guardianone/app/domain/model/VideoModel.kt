package com.guardianone.app.domain.model

data class VideoModel(
    val id: Long = 0,
    val fileName: String,
    val filePath: String,
    val fileSizeBytes: Long,
    val durationSeconds: Long,
    val startTimeMs: Long,
    val endTimeMs: Long,
    val peakMotionPercentage: Float,
    val isAutoRecorded: Boolean
)
